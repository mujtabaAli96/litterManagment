-- AlterTable
ALTER TABLE "Complain" ADD COLUMN "lang" TEXT;
ALTER TABLE "Complain" ADD COLUMN "lat" TEXT;
