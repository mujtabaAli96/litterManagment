-- RedefineTables
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Complain" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "phone" TEXT NOT NULL,
    "picture" TEXT,
    "location" TEXT,
    "lat" TEXT,
    "lang" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "status" INTEGER NOT NULL DEFAULT 1,
    "userId" INTEGER NOT NULL DEFAULT 1
);
INSERT INTO "new_Complain" ("createdAt", "id", "lang", "lat", "location", "name", "phone", "picture") SELECT "createdAt", "id", "lang", "lat", "location", "name", "phone", "picture" FROM "Complain";
DROP TABLE "Complain";
ALTER TABLE "new_Complain" RENAME TO "Complain";
PRAGMA foreign_key_check;
PRAGMA foreign_keys=ON;
